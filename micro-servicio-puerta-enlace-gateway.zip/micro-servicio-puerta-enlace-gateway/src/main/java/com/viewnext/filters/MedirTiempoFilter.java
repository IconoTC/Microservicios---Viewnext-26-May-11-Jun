package com.viewnext.filters;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

@Component
public class MedirTiempoFilter implements GlobalFilter{

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
		
		// Tomar el tiempo de inicio
		Long tiempoInicio = System.currentTimeMillis();
		
		return chain.filter(exchange).then(Mono.fromRunnable( () -> {
			// Todo lo que ejecute aqui sera el "post"
			
			// Tomar el tiempo final
			Long tiempoFinal = System.currentTimeMillis();
			
			// Mostrar la diferencia de tiempos
			System.out.println("******************************");
			System.out.println("Diferencia de tiempos: " + (tiempoFinal - tiempoInicio) + " mseg.");
			System.out.println("******************************");
			
		} ));
		
	}

}
