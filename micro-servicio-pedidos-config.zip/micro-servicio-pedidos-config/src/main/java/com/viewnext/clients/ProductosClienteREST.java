package com.viewnext.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.viewnext.models.Producto;

// Quitamos la URL porque sino siempre envia la peticion al puerto 8001
//@FeignClient(url = "localhost:8001", name = "servicio-productos")
@FeignClient(name = "servicio-productos")
public interface ProductosClienteREST {
	
	// Mapear a donde vamos a emitir la peticion
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id);

}
