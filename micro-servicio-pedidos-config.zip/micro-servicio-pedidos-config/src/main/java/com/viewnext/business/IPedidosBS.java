package com.viewnext.business;

import com.viewnext.models.Pedido;

public interface IPedidosBS {
	
	public Pedido crearPedido(Long id, int cantidad);

}
