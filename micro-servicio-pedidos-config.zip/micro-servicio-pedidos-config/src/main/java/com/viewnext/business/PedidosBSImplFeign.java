package com.viewnext.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.viewnext.clients.ProductosClienteREST;
import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

@Service
@Primary   // Le doy prioridad en la DI
public class PedidosBSImplFeign implements IPedidosBS{
	
	@Autowired
	private ProductosClienteREST clienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		Producto producto = clienteFeign.buscar(id);
		Pedido pedido = new Pedido(producto, cantidad);
		return pedido;
	}

}
