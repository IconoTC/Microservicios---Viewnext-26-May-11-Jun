package com.viewnext.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.business.ICarritoBS;
import com.viewnext.models.Carrito;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController
public class CarritoREST {
	
	@Autowired
	private ICarritoBS bs;
	
	// http://localhost:8003/crear/Pepito
	@PostMapping("/crear/{usuario}")
	@Operation(summary = "Crear el carrito", description = "Retorna el carrito creado con el nombre de usuario")
	@ApiResponse(responseCode = "200", description = "Respuesta crear carrito OK")
	public Carrito crear(@PathVariable String usuario) {
		return bs.crear(usuario);
	}
	
	// http://localhost:8003/agregar/id/3/cantidad/100/usuario/Pepito
	@PutMapping("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}")
	@Operation(summary = "Agregar pedido al carrito", description = "Retorna el carrito con el pedido agregado")
	@ApiResponse(responseCode = "200", description = "Respuesta agregar pedido al carrito OK")
	public Carrito agregarPedido(@PathVariable Long id, @PathVariable Integer cantidad, @PathVariable String usuario) {
		return bs.agregarPedido(id, cantidad, usuario);
	}
			
	// http://localhost:8003/consultar/Pepito
	@GetMapping("/consultar/{usuario}")
	@Operation(summary = "Consultar el carrito", description = "Retorna el carrito con el nombre de usuario")
	@ApiResponse(responseCode = "200", description = "Respuesta consultar carrito OK")
	public Carrito consultar(@PathVariable String usuario)  {
		return bs.consultar(usuario);
	}
	
	// http://localhost:8003/eliminar/id/3/usuario/Pepito
	@DeleteMapping("/eliminar/id/{id}/usuario/{usuario}")
	@Operation(summary = "Sacar pedido del carrito", description = "Retorna el carrito con el pedido eliminado")
	@ApiResponse(responseCode = "200", description = "Respuesta sacar pedido del carrito OK")
	public Carrito eliminarPedido(@PathVariable Long id, @PathVariable String usuario) {
		return bs.eliminarPedido(id, usuario);
	}

}
