package com.viewnext.models;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data  // getter, setter, equals, hashCode, toString
@NoArgsConstructor
@AllArgsConstructor
public class Producto implements Serializable{
	
	/*
	 * Para que lombok funcione se necesita tener instalado en Eclipse el plugin de Lombok
	 * Help / Install new software:   Lombok  -  https://projectlombok.org/p2
	 * */
	
	private Long ID;
	private String descripcion;
	private double precio;

}
