package com.viewnext.models;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.viewnext.utils.PrecioNegativoException;

public class ProductoTest {
	
	Producto producto;
	
	@BeforeAll
	// Debe ser estatico
	static void inicioClasePrueba() {
		System.out.println("Empezamos a probar la clase ProductoTest");
		System.out.println("****************************************");
	}
	
	@AfterAll
	// Debe ser estatico
	static void finClasePrueba() {
		System.out.println("******************************************");
		System.out.println("Terminamos de probar la clase ProductoTest");		
	}
	
	@BeforeEach
	void inicioPrueba() {
		producto = new Producto(1, "Impresora", 129.95);
		System.out.println("Producto creado para realizar la prueba");
	}
	
	@AfterEach
	void finPrueba() {
		System.out.println("Prueba terminada");
	}
	
	@Test
	@Tag("producto")
	@DisplayName("Probando la descripcion del producto")
	void testDescripcion() {
		//Producto producto = new Producto(1, "Impresora", 129.95);
		String descripcionReal = producto.getDescripcion();
		String descripcionEsperada = "Impresora";
		Assertions.assertEquals(descripcionEsperada, descripcionReal);
	}
	
	@Test
	@Tag("producto")
	void testIgualdadProductos() {
		//Producto producto = new Producto(1, "Impresora", 129.95);
		Producto producto2 = new Producto(1, "Impresora", 129.95);
		Assertions.assertEquals(producto, producto2);
	}
	
	
	@Nested
	class PruebasPrecio{
		@Test
		void testPrecio() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			//Assertions.assertTrue(producto.getPrecio() > 0);
			Assertions.assertFalse(producto.getPrecio() <= 0);
		}
		
		// comparar el precio si es negativo lanzar excepcion
		@Test
		void testPrecioNegativoException() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Exception ex = Assertions.assertThrows(PrecioNegativoException.class, () -> {
				producto.setPrecio(-23);
			});
				
			String msgReal = ex.getMessage();
			String msgEsperado = "El precio no puede ser negativo";
			
			Assertions.assertEquals(msgEsperado, msgReal);
		}
	}
	
	@Nested
	class SO_JRE{
		
		@Test
		@EnabledOnOs(OS.WINDOWS)   // Tambien @DisabledOnOs
		void testSOWindows() {
			System.out.println("Se ejecuta si el SO es Windows");
		}
		
		@Test
		@DisabledOnJre(JRE.JAVA_21)  // Tambien @EnabledOnJre
		void testJava21() {
			System.out.println("Deshabilita si tenemos Java 21");
		}
	}
	
	
	@Nested
	class TestRepetidos{
		
		//@RepeatedTest(value = 3)
		@RepeatedTest(value = 3, name = "Repeticion nº {currentRepetition} del total de {totalRepetitions}")
		void testRepetido(RepetitionInfo infoRep) {
			System.out.println("Estamos en la repeticion numero: " + infoRep.getCurrentRepetition());
			double numero = Math.random();
			Assertions.assertNotNull(numero);
			Assertions.assertTrue(numero >= 0);
		}
	}
	
	
	@Nested
	class TestParametrizados{
		
		@ParameterizedTest(name = "parametro {index} con valor {0}")
		@ValueSource(doubles = {34, 0 , -12})   // array de parametros
		void testPrecios(double precio) {
			producto.setPrecio(precio);
			Assertions.assertTrue(producto.getPrecio() > 0);
		}
		
		@ParameterizedTest(name = "parametro {index} con valor {0}")
		@CsvSource({"34", "0" , "-12"})   // csv de parametros
		void testPreciosCsv(double precio) {
			producto.setPrecio(precio);
			Assertions.assertTrue(producto.getPrecio() > 0);
		}
		
		@ParameterizedTest(name = "parametro {index} con valor {0}")
		@CsvFileSource(resources = "/datos.csv")   // archivo csv de parametros
		void testPreciosCsvFile(double precio) {
			producto.setPrecio(precio);
			Assertions.assertTrue(producto.getPrecio() > 0);
		}
		
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@MethodSource("queryPrecios")   // metodo que retorna la listade parametros
	void testPreciosMetodo(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	static List<Double> queryPrecios(){
		// Simulamos que lanzamos una query a la BBDD para traer la lista de precios
		return Arrays.asList(34.0, 0.0, -12.0);
	}
	
	@Nested
	class pruebasTimeout{
		
		@Test
		@Timeout(value = 1000, unit = TimeUnit.MILLISECONDS)
		void testTiempo() throws InterruptedException {
			// Si tarda mas de 1 segundo en ejecutarse, la prueba no sera valida
			
			// Forzamos que el hilo espere 2 segundos
			Thread.sleep(2000);
		}
		
		// Hay otra forma de hacerlo
		@Test
		void testTiempo2() throws InterruptedException {
			// Si tarda mas de 1 segundo en ejecutarse, la prueba no sera valida
			
			Assertions.assertTimeout(Duration.ofSeconds(1), () -> {
				// Forzamos que el hilo espere 2 segundos
				//Thread.sleep(2000);   // La prueba falla
				Thread.sleep(500);   // pasa la prueba
			});
			
		}
	}
	
	
	/*
	 * EJERCICIO
	 * 	1.- Crear productos.csv con 4 productos   id,descripcion,precio
	 * 	2.- Crear una prueba parametrizada comprobando si la descripcion tiene 3 caracteres o mas
	 * 	3.- La prueba fallara si tarda mas de 2 segundos
	 * */
	
	@ParameterizedTest
	@CsvFileSource(resources = "/productos.csv")
	@Timeout(value = 2000, unit = TimeUnit.MILLISECONDS)
	void testProductosCsv(int id, String descripcion, double precio) throws InterruptedException {
		assertTrue(descripcion.length() >= 3);
		
		// Forzamos que el hilo espere 2 segundos
		Thread.sleep(3000);
	}
	
	
	// Otra forma de hacerlo
	@ParameterizedTest
	@CsvFileSource(resources = "/productos.csv")
	void testProductosCsv2(int id, String descripcion, double precio) throws InterruptedException {
		
		// Agrupar todas las aserciones
		Assertions.assertAll(
			() -> Assertions.assertTrue(descripcion.length() >= 3),
			() -> Assertions.assertTimeout(Duration.ofSeconds(2), () -> {
						// Forzamos que el hilo espere 3 segundos
						Thread.sleep(3000);   // La prueba falla
						// Thread.sleep(500);  // pasa la prueba
					})
		);			
	}

}














