package com.viewnext.utils;

public class PrecioNegativoException extends RuntimeException{
	
	public PrecioNegativoException(String mensaje) {
		super(mensaje);
	}

}
