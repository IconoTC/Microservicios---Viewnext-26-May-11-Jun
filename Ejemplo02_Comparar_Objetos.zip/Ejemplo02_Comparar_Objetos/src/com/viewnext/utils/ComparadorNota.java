package com.viewnext.utils;

import java.util.Comparator;

import com.viewnext.models.Alumno;

public class ComparadorNota implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		// 1 o cualquier valor positivo cuando alum1 > alum2
		// -1 o cualquier valor negativo cuando alum1 < alum2
		// 0 si los dos son iguales
		if (alum1.getNota() > alum2.getNota()) {
			return 1;
		} else if (alum1.getNota() < alum2.getNota()) {
			return -1;
		}
		return 0;
	}

}
