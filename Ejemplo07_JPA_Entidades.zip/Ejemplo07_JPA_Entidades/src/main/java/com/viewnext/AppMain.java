package com.viewnext;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.viewnext.models.Direccion;
import com.viewnext.models.EstadoCivil;
import com.viewnext.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		// 1.- EntityManagerFactory con los datos de la unidad de persistencia PU
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// 2.- EntityManager  es el eje central de JPA
		EntityManager em = emf.createEntityManager();   // En este momento se abre la conexion a la BBDD
		
		// 3.- Obtenemos una transaccion
		EntityTransaction et = em.getTransaction();
		
		// 4.- Crear instancias de Persona
		Persona p1 = new Persona(616111111L, "1111111-A", "Pedro", 31, EstadoCivil.SOLTERO, 'V', 
				new Direccion("Gran Via", "Madrid", 28014), 
				new Date("25/1/1997"), 
				"Arquitecto, licenciado en la Politecica, ......");
		
		Persona p2 = new Persona(616222222L, "2222222-B", "Maria", 27, EstadoCivil.SOLTERO, 'H', 
				new Direccion("Mayor", "Madrid", 28100), 
				new Date("26/3/1998"), 
				"Ingeniera, licenciado en la Politecica, ......");
		
		Persona p3 = new Persona(616333333L, "3333333-C", "Juan", 40, EstadoCivil.CASADO, 'V', 
				new Direccion("Diagonal", "Barcelona", 8014), 
				new Date("18/10/1983"), 
				"Periodista, licenciado en la Complutense, ......");
		
		// 5.- Persistir las entidades
		try {
			et.begin();
			
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			// Nos aseguramos de cerrar la conexion
			em.close();
		}

	}

}
