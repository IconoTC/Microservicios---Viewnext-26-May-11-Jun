package com.viewnext.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Lob;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@IdClass(PersonaPK.class)
@Table(name = "Ejemplo7_Personas")
@SecondaryTable(name = "Ejemplo7_CV",
		pkJoinColumns = {
			@PrimaryKeyJoinColumn(name="id_telefono", referencedColumnName = "id_telefono"),
			@PrimaryKeyJoinColumn(name="id_nif", referencedColumnName = "id_nif")
		}
)
public class Persona implements Serializable{
	
	@Id
	@Column(name = "id_telefono", nullable = false)
	private Long telefono;
	
	@Id
	@Column(name = "id_nif", nullable = false)
	private String nif;
	
	private String nombre;
	
	private int edad;
	
	@Enumerated(EnumType.STRING)
	private EstadoCivil estado;
	
	@Column(length = 1)
	private char sexo;
	
	@Embedded
	private Direccion direccion;
	
	@Temporal(TemporalType.DATE)
	private Date fechaNacimiento;
	
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(table = "Ejemplo7_CV")
	private String cv;
	
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(Long telefono, String nif, String nombre, int edad, EstadoCivil estado, char sexo,
			Direccion direccion, Date fechaNacimiento, String cv) {
		super();
		this.telefono = telefono;
		this.nif = nif;
		this.nombre = nombre;
		this.edad = edad;
		this.estado = estado;
		this.sexo = sexo;
		this.direccion = direccion;
		this.fechaNacimiento = fechaNacimiento;
		this.cv = cv;
	}

	public Long getTelefono() {
		return telefono;
	}

	public void setTelefono(Long telefono) {
		this.telefono = telefono;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public EstadoCivil getEstado() {
		return estado;
	}

	public void setEstado(EstadoCivil estado) {
		this.estado = estado;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getCv() {
		return cv;
	}

	public void setCv(String cv) {
		this.cv = cv;
	}

	@Override
	public String toString() {
		return "Persona [telefono=" + telefono + ", nif=" + nif + ", nombre=" + nombre + ", edad=" + edad + ", estado="
				+ estado + ", sexo=" + sexo + ", direccion=" + direccion + ", fechaNacimiento=" + fechaNacimiento
				+ ", cv=" + cv + "]";
	}
	
	

}
