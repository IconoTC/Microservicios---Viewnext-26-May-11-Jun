package com.viewnext.models;

import java.io.Serializable;
import java.util.Objects;

public class PersonaPK implements Serializable {

	private Long telefono;
	private String nif;

	public PersonaPK() {
		// TODO Auto-generated constructor stub
	}

	public PersonaPK(Long telefono, String nif) {
		super();
		this.telefono = telefono;
		this.nif = nif;
	}

	public Long getTelefono() {
		return telefono;
	}

	public void setTelefono(Long telefono) {
		this.telefono = telefono;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	@Override
	public int hashCode() {
		return Objects.hash(nif, telefono);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonaPK other = (PersonaPK) obj;
		return Objects.equals(nif, other.nif) && Objects.equals(telefono, other.telefono);
	}

}
