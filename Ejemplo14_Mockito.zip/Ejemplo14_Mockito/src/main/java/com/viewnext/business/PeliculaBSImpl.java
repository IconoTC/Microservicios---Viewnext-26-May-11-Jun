package com.viewnext.business;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.IPeliculaDAO;

public class PeliculaBSImpl implements IPeliculaBS {

	private IPeliculaDAO dao;

	public PeliculaBSImpl(IPeliculaDAO dao) {
		super();
		this.dao = dao;
	}

	@Override
	public Pelicula buscarPelicula(String nombre) {

		return dao.findAll()
				.stream()
				.filter(peli -> peli.getNombre().contains(nombre))
				.findFirst()
				.get();
	}

}
