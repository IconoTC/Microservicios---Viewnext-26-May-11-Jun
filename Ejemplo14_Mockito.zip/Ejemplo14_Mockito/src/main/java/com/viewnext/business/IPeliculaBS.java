package com.viewnext.business;

import com.viewnext.models.Pelicula;

public interface IPeliculaBS {
	
	Pelicula buscarPelicula(String nombre);

}
