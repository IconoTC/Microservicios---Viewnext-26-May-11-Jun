package com.viewnext;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.viewnext.business.PeliculaBSImpl;
import com.viewnext.models.Pelicula;
import com.viewnext.persistence.PeliculaDAOImpl;

@ExtendWith(MockitoExtension.class)   // Para activar las anotaciones
public class TestPeliculas {
	
	// Para poder llamar a los metodos necesitamos tener la clase y no la interface
	@Mock
	PeliculaDAOImpl dao;
	
	@InjectMocks
	PeliculaBSImpl bs;
	
	
	@Test
	void testBuscarPelicula() {
		List<Pelicula> datos = Arrays.asList(
				new Pelicula(1L, "El 47"),
				new Pelicula(2L, "La infiltrada"),
				new Pelicula(3L, "La habitacion de al lado")
			);
		
		Mockito.when(dao.findAll()).thenReturn(datos);
		
		Pelicula pelicula = bs.buscarPelicula("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
	}

}
