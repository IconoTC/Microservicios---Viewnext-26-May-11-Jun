package com.viewnext;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.ProducerConfig;

public class Consumidor {

	public static void main(String[] args) {
		Properties props = new Properties();

		// Especificar los host y puertos de todos los brokers del cluster
		// Asegurarnos que tenemos levantados los 3 brokers y zookeeper
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");

		// Elegir como deserializar la clave y el valor del mensaje
		props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		// El consumidor pertenece al grupo 1
		props.put("group.id", "grupo1");
		
		// Timeout por defecto de 10 segundos
		props.put("session.timeout.ms", 10_000);
		
		// Cantidad minima de bytes que quiere recibir
		props.put("fetch.min.bytes", "1");
		
		// Cuanto tiempo como maximo esta dispuesto a esperar
		props.put("fetch.max.wait.ms", "1000");   // milisegundos
		
		// Crear el consumidor con las propiedades establecidas
		KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);
		
		// El consumidor se conecta al topic para recibir los mensajes
		consumer.subscribe(Collections.singletonList("viewnext-cluster"));

		try {
			while(true) {
				// El consumidor recibe los mensajes y le indico el tiempo de espera
				ConsumerRecords<String, String> mensajes = consumer.poll(Duration.ofSeconds(10));
				
				for (ConsumerRecord<String, String> msg : mensajes) {
					System.out.println("Topic: " + msg.topic());
					System.out.println("Particion: " + msg.partition());
					System.out.println("Key: " + msg.key());
					System.out.println("Value: " + msg.value());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Cerrar el consumidor
			consumer.close();
		}
	}

}
