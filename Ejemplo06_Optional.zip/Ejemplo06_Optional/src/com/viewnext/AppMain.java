package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		System.out.println(dao.buscar(2).get());
		
		// java.util.NoSuchElementException: No value present
		//System.out.println(dao.buscar(25).get());
		
		// Si el producto existe en el optional lo recuperamos
		Optional<Producto> opProd = dao.buscar(25);
		if (opProd.isPresent()) {
			System.out.println(opProd.get());
		}
		
		// Si el producto no existe en el optional mostramos mensaje
		if (opProd.isEmpty()) {
			System.out.println("Ese producto no existe en nuestro catalogo");
		}
		
		// Recuperamos el producto del optional y si no hay creamos otro alternativo
		System.out.println(opProd.orElse(new Producto()));
		
		// Si el producto no existe en el optional lanzamos una excepcion
		opProd.orElseThrow();  // java.util.NoSuchElementException: No value present

	}

}
