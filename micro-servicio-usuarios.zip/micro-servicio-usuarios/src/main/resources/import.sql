INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('juan', '$2a$10$.M3z2AjXT0coaXtmXNZwQuvVpzMqqJJh/zOdsz8uywP4IDoecWMOu', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('admin', '$2a$10$r9NsupVZ4cwMoOkOtl/9YOJUl7fLQ0sG10g1qa4kkiBcRXvfO/DSS', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles (nombre) VALUES ('ROLE_USER');
INSERT INTO roles (nombre) VALUES ('ROLE_ADMIN');

INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (1,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,2);