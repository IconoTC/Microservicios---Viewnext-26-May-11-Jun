package com.viewnext;

import java.util.stream.IntStream;

public class AppMain {
	
	// Los Parallel Streams son para procesar colecciones de forma paralela
	// sacando partido a todos los procesadores.
	
	// Permite dividir la tarea utilizando streams de forma automatica
	// Son utiles con operaciones donde no depende el orden de ejecución
	
	// Agiliza mucho el tiempo

	public static void main(String[] args) {
		
		
		// Ejemplo 1: sumar numeros utilizando un stream secuencial
		long tiempoInicio = System.currentTimeMillis();
		int suma = IntStream.rangeClosed(1,100)
				.map(n -> {
					try {
						// parar el hilo durante 10 milisegundos
						Thread.sleep(10);
					} catch(Exception ex) {
						ex.printStackTrace();
					}
					return n;
				})
				.sum();
		
		long tiempoFinal = System.currentTimeMillis();
		System.out.println("Suma: " + suma);
		System.out.println("Tiempo suma secuencial: " + (tiempoFinal - tiempoInicio) + " mseg.");
		
		
		// Ejemplo 2: sumar numeros utilizando parallel streams
		tiempoInicio = System.currentTimeMillis();
		int sumaParallel = IntStream.rangeClosed(1,100).parallel()
				.map(n -> {
					try {
						// parar el hilo durante 10 milisegundos
						Thread.sleep(10);
					} catch(Exception ex) {
						ex.printStackTrace();
					}
					return n;
				})
				.sum();
		
		tiempoFinal = System.currentTimeMillis();
		System.out.println("Suma: " + sumaParallel);
		System.out.println("Tiempo suma parallel: " + (tiempoFinal - tiempoInicio) + " mseg.");
		

	}

}
