create table VALORACIONES(
	ID integer not null AUTO_INCREMENT,
	MENSAJE varchar(255),
	primary key (ID)
);