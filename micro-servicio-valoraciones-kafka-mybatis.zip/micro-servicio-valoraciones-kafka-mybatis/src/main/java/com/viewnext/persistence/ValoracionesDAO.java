package com.viewnext.persistence;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.viewnext.models.Valoracion;

@Mapper
public interface ValoracionesDAO {
	
	// Consultar todas las valoraciones
	// http://localhost:8014/valoraciones
	
	@Select("select * from VALORACIONES")
	public List<Valoracion> findAll();
	
	
	@Select("select * from VALORACIONES where ID = #{id}")
	public List<Valoracion> findById(Integer id);
	
	
	@Insert("insert into VALORACIONES (MENSAJE) values (#{mensaje})")
	public int insert(Valoracion valoracion);

}
