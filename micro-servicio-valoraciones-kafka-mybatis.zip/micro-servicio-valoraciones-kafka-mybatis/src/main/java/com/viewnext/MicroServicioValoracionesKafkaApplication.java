package com.viewnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MicroServicioValoracionesKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioValoracionesKafkaApplication.class, args);
	}

}
