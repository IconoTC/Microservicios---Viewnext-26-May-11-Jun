package com.viewnext.models;

import java.io.Serializable;


public class Valoracion implements Serializable{

	private int ID; 
	private String mensaje;
	
	public Valoracion() {
		// TODO Auto-generated constructor stub
	}

	public Valoracion(String mensaje) {
		super();
		this.mensaje = mensaje;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	@Override
	public String toString() {
		return "Valoracion [ID=" + ID + ", mensaje=" + mensaje + "]";
	}
	
	
}
