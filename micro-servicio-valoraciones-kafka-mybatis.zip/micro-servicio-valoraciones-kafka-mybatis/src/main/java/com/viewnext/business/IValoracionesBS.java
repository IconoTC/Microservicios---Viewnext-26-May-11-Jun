package com.viewnext.business;

public interface IValoracionesBS {
	
	void crearValoracion(String mensaje);

}
