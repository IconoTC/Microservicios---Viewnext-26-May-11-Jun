package com.viewnext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

import com.viewnext.business.PruebaCacheBS;

@SpringBootApplication
@EnableCaching   // Habilitar la cache
public class Ejemplo19SpringCacheApplication implements CommandLineRunner{
	
	@Autowired
	private PruebaCacheBS bs;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo19SpringCacheApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		for (int i=1; i<= 5; i++) {
			System.out.println("Numero: " + bs.hallarNumero());
		}
		
	}

}
