package com.viewnext.business;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class PruebaCacheBS {
	
	@Cacheable("num")
	public int hallarNumero() {
		long tiempoInicio = System.currentTimeMillis();
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		long tiempoFinal = System.currentTimeMillis();
		System.out.println("Tiempo: " + (tiempoFinal - tiempoInicio) + " mseg.");
		return (int) (Math.random() * 10);
	}

}
