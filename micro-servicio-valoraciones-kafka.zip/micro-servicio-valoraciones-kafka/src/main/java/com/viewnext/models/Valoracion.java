package com.viewnext.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VALORACIONES")
public class Valoracion implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // incremental
	@Column(name = "ID")
	private int ID; 
	
	@Column(name = "MENSAJE")
	private String mensaje;
	
	public Valoracion() {
		// TODO Auto-generated constructor stub
	}

	public Valoracion(String mensaje) {
		super();
		this.mensaje = mensaje;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	@Override
	public String toString() {
		return "Valoracion [ID=" + ID + ", mensaje=" + mensaje + "]";
	}
	
	
}
