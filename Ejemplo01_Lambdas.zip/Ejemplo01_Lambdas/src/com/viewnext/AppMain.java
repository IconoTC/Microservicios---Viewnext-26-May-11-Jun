package com.viewnext;

import com.viewnext.business.ItfzEmpleados;

public class AppMain {

	public static void main(String[] args) {
		
		// Sintaxis: (parametros) -> {cuerpo del metodo}
		// Los parentesis son obligatorios:
		//		- ponemos el tipo al parametro,
		//		- cuando tenemos mas de un parametro
		// Las llaves son obligatorias:
		//		- tenemos mas de una linea de codigo
		//		- ponemos return
		
		ItfzEmpleados lambda1 = (nombre, edad) -> "Nombre: " + nombre + ", edad: " + edad;
		System.out.println(lambda1.detalle("Juan", 35));
		
		ItfzEmpleados lambda2 = (nombre, edad) ->  {
			return "Nombre: " + nombre + ", edad: " + edad;
		};
		System.out.println(lambda2.detalle("Juan", 35));

		ItfzEmpleados lambda3 = (nombre, edad) ->  {
			nombre = nombre.toUpperCase();
			edad += 1;
			return "Nombre: " + nombre + ", edad: " + edad;
		};
		System.out.println(lambda3.detalle("Juan", 35));
		
		// Los parametros no tienen porque llamarse igual que en la declaración de la interface
		ItfzEmpleados lambda4 = (n, e) -> "Nombre: " + n + ", edad: " + e;
		System.out.println(lambda4.detalle("Juan", 35));
		
		// Podemos poner el tipo de dato a los parametros (a los dos o ninguno)
		ItfzEmpleados lambda5 = (String nombre, int edad) -> "Nombre: " + nombre + ", edad: " + edad;
		System.out.println(lambda5.detalle("Juan", 35));
		
		// Podemos utilizar inferencia de tipo de dato a los parametros (a los dos o ninguno)
		ItfzEmpleados lambda6 = (var nombre, var edad) -> "Nombre: " + nombre + ", edad: " + edad;
		System.out.println(lambda6.detalle("Juan", 35));
	}

}
