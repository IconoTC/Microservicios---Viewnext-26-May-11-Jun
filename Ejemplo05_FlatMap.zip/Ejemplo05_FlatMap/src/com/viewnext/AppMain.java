package com.viewnext;

import java.util.Arrays;
import java.util.List;

import com.viewnext.models.Persona;
import com.viewnext.models.Viaje;

public class AppMain {
	
	/*
	 * flatMap es una operacion de streams que permite aplanar estructuras
	 * de datos anidadas (listas que contienen listas)
	 * Es util para evitar dobles bucles anidados
	 * y procesar todos los datos de forma conjunta
	 * */

	public static void main(String[] args) {
		
		Persona juan = new Persona("Juan");
		juan.addViaje(new Viaje("Italia"));
		juan.addViaje(new Viaje("Francia"));
		juan.addViaje(new Viaje("Alemania"));
		
		Persona maria = new Persona("Maria");
		maria.addViaje(new Viaje("Portugal"));
		maria.addViaje(new Viaje("Brasil"));
		
		List<Persona> personas = Arrays.asList(juan, maria);
		
		// Mostrar que paises han visitado entre los 2
		for (Persona persona : personas) {
			for (Viaje viaje: persona.getViajes()) {
				System.out.println(viaje.getPais());
			}
		}
		System.out.println("-----------------------");
		
		
		// Utilizando flatMap
		personas.stream()
			.flatMap(p -> p.getViajes().stream())
			.map(v -> v.getPais())
			.forEach(System.out::println);

	}

}





