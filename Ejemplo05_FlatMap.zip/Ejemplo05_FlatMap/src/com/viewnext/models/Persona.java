package com.viewnext.models;

import java.util.ArrayList;
import java.util.List;

public class Persona {

	private String nombre;
	private List<Viaje> viajes = new ArrayList<>();

	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nombre) {
		super();
		this.nombre = nombre;
	}
	
	public void addViaje(Viaje viaje) {
		viajes.add(viaje);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Viaje> getViajes() {
		return viajes;
	}

	public void setViajes(List<Viaje> viajes) {
		this.viajes = viajes;
	}

	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", viajes=" + viajes + "]";
	}

}
