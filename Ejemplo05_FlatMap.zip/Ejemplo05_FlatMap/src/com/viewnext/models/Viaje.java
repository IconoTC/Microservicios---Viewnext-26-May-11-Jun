package com.viewnext.models;

public class Viaje {

	private String pais;

	public Viaje() {
		// TODO Auto-generated constructor stub
	}

	public Viaje(String pais) {
		super();
		this.pais = pais;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	@Override
	public String toString() {
		return "Viaje [pais=" + pais + "]";
	}

}
