package com.viewnext.batch;

import java.util.List;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.viewnext.models.Producto;

@Component
public class JobProductosListener extends JobExecutionListenerSupport{
	
	private long inicio;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public void beforeJob(JobExecution jobExecution) {
		inicio = System.currentTimeMillis();
		System.out.println("Iniciando el proceso Job -------------------");
	}
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		
		// Comprobamos si la tarea se ha completado
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			List<Producto> lista = jdbcTemplate.query("select * from productos", 
					(resultSet, row) -> new Producto(
							resultSet.getInt("id"), 
							resultSet.getString("descripcion"), 
							resultSet.getDouble("precio")));
			lista.forEach(System.out::println);
		}
		
		System.out.println("Finalizando el proceso Job -------------------");
		
		long fin = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuccion: " + (fin - inicio) + " mseg.");
	}

}
