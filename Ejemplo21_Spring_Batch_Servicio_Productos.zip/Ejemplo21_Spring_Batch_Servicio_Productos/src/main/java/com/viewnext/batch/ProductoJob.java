package com.viewnext.batch;

import org.springframework.batch.item.ItemProcessor;

import com.viewnext.models.Producto;

public class ProductoJob implements ItemProcessor<Producto, Producto>{
	
	// Estamos en rebajas y aplicamos un dto del 10% del precio
	// Ademas, la descripcion la pongo en mayusculas

	@Override
	public Producto process(Producto producto) throws Exception {
		
		double precio = producto.getPrecio() * 0.9;
		String descripcion = producto.getDescripcion().toUpperCase();
		
		Producto procesado = new Producto(producto.getId(), descripcion, precio);
		System.out.println("Producto original: " + producto);
		System.out.println("Producto procesado: " + procesado);
		
		return procesado;
	}

}
