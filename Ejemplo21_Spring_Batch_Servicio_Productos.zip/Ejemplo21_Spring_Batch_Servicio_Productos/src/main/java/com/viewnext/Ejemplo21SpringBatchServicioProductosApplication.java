package com.viewnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo21SpringBatchServicioProductosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo21SpringBatchServicioProductosApplication.class, args);
	}

}
