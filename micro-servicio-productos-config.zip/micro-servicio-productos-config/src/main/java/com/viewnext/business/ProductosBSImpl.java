package com.viewnext.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

/*
 * @Repository    -> DAO y repositorios de datos
 * @Service    -> Clases de Servicios, Business
 * @Controller   ->  Controladores
 * @Component   -> Cualquier clase
 * */


@Service   // Genere un bean y lo meta en el contenedor
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired   // Inyeccion de dependencias DI
	private ProductosDAO dao;

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

}
