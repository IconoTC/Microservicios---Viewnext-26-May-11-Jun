package com.viewnext.rest;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.business.IProductosBS;
import com.viewnext.models.Producto;

@RefreshScope
@RestController
public class ProductosREST {
	
	// Inyectar el valor de la propiedad recuperada del servidor de configuracion
	@Value("${configuracion.modo}")
	private String texto;
	
	// Con puerto dinamico no funciona
//	@Value("${server.port}")
//	private Integer port;
	
	// A cambio, inyectamos la peticion
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private IProductosBS bs;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					// prod.setPort(port);
					prod.setPort(request.getLocalPort());
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/3
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id) throws InterruptedException {
		
		// Mostrar el modo de configuracion
		System.out.println("********************** " + texto);
		
		Producto producto = bs.buscarProducto(id);
		
		// Si no encontramos el producto, lanzaremos una excepcion
		if (producto.getDescripcion() == null) {
			throw new RuntimeException("Error al buscar el producto");
		}
		
		// Probar las peticiones lentas
		if (id == 5L) {
			Thread.sleep(5000);
		}
			
		//producto.setPort(port);
		producto.setPort(request.getLocalPort());
		return producto;
	}

}
