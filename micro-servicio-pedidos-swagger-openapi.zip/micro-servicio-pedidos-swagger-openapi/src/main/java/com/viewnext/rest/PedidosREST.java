package com.viewnext.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.business.IPedidosBS;
import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController
public class PedidosREST {
	
	@Autowired
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/3/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	//@HystrixCommand(fallbackMethod = "manejarError")
	@CircuitBreaker(fallbackMethod = "manejarError", name = "pedidos")
	@Operation(summary = "Crear un pedido", description = "Retorna un pedido con el producto encontrado y la cantidad")
	@ApiResponse(responseCode = "200", description = "Respuesta crear pedido OK")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// El metodo alternativo ha de tener los mismos argumentos + Throwable
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + " ************************");
		System.out.println(ex.getClass() + " ........................");
		
		Producto producto = new Producto(id, "Producto vacio", 0, null);
		return new Pedido(producto, cantidad);
	}

}
