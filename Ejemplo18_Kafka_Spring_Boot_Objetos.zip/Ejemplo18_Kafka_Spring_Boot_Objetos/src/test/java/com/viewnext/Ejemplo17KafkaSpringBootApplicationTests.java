package com.viewnext;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo17KafkaSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
