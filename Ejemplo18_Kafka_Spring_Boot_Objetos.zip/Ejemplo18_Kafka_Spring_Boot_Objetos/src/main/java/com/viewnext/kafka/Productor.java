package com.viewnext.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.viewnext.models.Producto;

@Service
public class Productor {
	
	@Autowired
	private KafkaTemplate<String, Object> kafkaTemplate;
	
	public void enviarMensaje(Producto producto) {
		kafkaTemplate.send("viewnext-cluster" , producto);
	}

}
