package com.viewnext.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.viewnext.models.Producto;

@Service
public class Consumidor {
	
	@KafkaListener(topics = "viewnext-cluster")
	public void recibirMensaje(Producto producto) {
		System.out.println("Producto recibido: " + producto);
	}

}
