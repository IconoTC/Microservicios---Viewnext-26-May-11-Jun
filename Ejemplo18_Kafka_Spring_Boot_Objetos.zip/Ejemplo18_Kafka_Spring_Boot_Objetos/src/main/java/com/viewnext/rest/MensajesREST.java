package com.viewnext.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.kafka.Productor;
import com.viewnext.models.Producto;

@RestController
public class MensajesREST {
	
	@Autowired
	private Productor productor;
	
	// http://localhost:8080/kafka/id/3/descripcion/Silla/precio/89.50
	@GetMapping("/kafka/id/{id}/descripcion/{descripcion}/precio/{precio}")
	public void envios(@PathVariable int id, @PathVariable String descripcion, @PathVariable double precio) {
		Producto producto = new Producto(id, descripcion, precio);
		productor.enviarMensaje(producto);
	}

}
