package com.viewnext.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Productor {
	
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	public void enviarMensaje(String mensaje) {
		kafkaTemplate.send("viewnext-cluster" , mensaje);
	}

}
