package com.viewnext.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class Consumidor {
	
	@KafkaListener(topics = "viewnext-cluster")
	public void recibirMensaje(String mensaje) {
		System.out.println("Mensaje recibido: " + mensaje);
	}

}
