package com.viewnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo17KafkaSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo17KafkaSpringBootApplication.class, args);
	}

}
