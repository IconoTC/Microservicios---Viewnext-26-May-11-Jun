package com.viewnext.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/*
 * La estrategia TABLE PER CLASS significa que todas las entidades y subentidades
 * se guardan en su tabla tablas, sin estar relaccionadas entre si
 * Esta estrategia NO necesita de un campo discriminador
 * INCONVENIENTE: Habra varias tablas
 * VENTAJA: Todos los datos de la entidad los tienes en la misma tabla
 * */

@Entity
@Table(name = "Ejemplo11_Personas")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class Persona implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) // Autoincremental
	@Column(name = "id_persona", nullable = false)
	private Long id;

	private String nombre;
	private String apellido;

	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nombre, String apellido) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	@Override
	public String toString() {
		return "Persona [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + "]";
	}

}