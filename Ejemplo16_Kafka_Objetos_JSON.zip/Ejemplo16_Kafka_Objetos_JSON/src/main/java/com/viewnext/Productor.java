package com.viewnext;

import java.util.Properties;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.viewnext.models.Producto;

public class Productor {
	
	public static void main(String[] args) throws JsonProcessingException {
		Properties props = new Properties();
		
		// Especificar los host y puertos de todos los brokers del cluster
		// Asegurarnos que tenemos levantados los 3 brokers y zookeeper
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");
		
		// Elegir como serializar la clave y el valor del mensaje
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		
		// Numero de intentos en caso de fallo
		props.put("retries", 0);
		
		// acknowledges -> confirmacion de recibo del mensaje
		// acks = 0. El productor no recibe ninguna confirmación si el mensaje se ha enviado correctamente o no.
		// acks = 1. El productor espera la confirmacion del mensaje del broker que lo ha recibido
		// acks = all. El productor espera la confirmacion del mensaje de todos los broker sincronizados.
		// Esta ultima es la mas segura, pero es la mas lenta.
		props.put("acks", "all");
		
		// Tamaño del buffer
		props.put("batch.size", 20_000);
		
		// Memoria disponible para el productor
		props.put("buffer.memory", 400_000);
		
		// Crear el productor con las propiedades establecidas
		KafkaProducer<String, String> prod = new KafkaProducer<>(props);
		
		// Para enviar mensajes necesitamos: topic, particion, key, value
		String topic = "viewnext-cluster";
		int particion = 0;
		String key = "producto-1";
		Producto producto = new Producto(1, "Pantalla", 137.50);
		String value = new ObjectMapper().writeValueAsString(producto);
		
		// 1ª opcion: envio asincrono
		// prod.send(new ProducerRecord<String, String>(topic, particion, key, value));
		
		// 2ª opcion: envio sincrono
//		try {
//			prod.send(new ProducerRecord<String, String>(topic, particion, key, value)).get();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		// 3ª opcion: envio asincrono con callback
		prod.send(new ProducerRecord<String, String>(topic, particion, key, value), new Callback() {
			
			@Override
			public void onCompletion(RecordMetadata metadata, Exception exception) {
				if (exception != null) {
					System.out.println("Ha habido un error");
					exception.printStackTrace();
				} else {
					System.out.println("Mensaje enviado con exito");
				}	
			}
		});
		
		
		// Cerrar el productor
		prod.close();
	}

}
