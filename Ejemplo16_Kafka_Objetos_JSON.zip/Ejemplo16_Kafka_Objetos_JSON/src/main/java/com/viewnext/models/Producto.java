package com.viewnext.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data  // getter, setter, equals, hashcode, toString
@AllArgsConstructor
@NoArgsConstructor
public class Producto {

	private int ID;
	private String descripcion;
	private double precio;
}
