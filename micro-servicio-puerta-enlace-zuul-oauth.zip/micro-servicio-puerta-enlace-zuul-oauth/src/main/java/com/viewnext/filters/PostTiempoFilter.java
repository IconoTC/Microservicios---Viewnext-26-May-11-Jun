package com.viewnext.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PostTiempoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		// Activar o desactivar el filtro
		// Si retorna true -> filtro activado
		// Si retorna false -> filtro desactivado
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// Todo el codigo que quiero que se ejecute en este filtro
		
		// Tomar el tiempo final
		Long tiempoFinal = System.currentTimeMillis();
		
		// Recupero el tiempo de inicio como atributo de peticion
		RequestContext ctx = RequestContext.getCurrentContext();
		Long tiempoInicio = (Long) ctx.getRequest().getAttribute("tiempoInicio");
		
		// Mostrar la diferencia de tiempos
		System.out.println("****************************************");
		System.out.println("Tiempo transcurrido: " + (tiempoFinal - tiempoInicio) + " mseg");
		System.out.println("****************************************");
		
		return null;
	}

	@Override
	public String filterType() {
		// En que momento se ejecuta el filtro
		// Hay que retornar uno de estos valores: "pre", "post", "route"
		return "post";
	}

	@Override
	public int filterOrder() {
		// Orden de ejecucion en el caso de tener mas de un filtro
		return 1;
	}

}
