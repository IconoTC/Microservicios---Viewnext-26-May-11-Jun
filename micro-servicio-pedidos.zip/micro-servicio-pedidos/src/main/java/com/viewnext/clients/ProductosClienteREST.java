package com.viewnext.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.viewnext.models.Producto;

@FeignClient(url = "localhost:8001", name = "servicio-productos")
public interface ProductosClienteREST {
	
	// Mapear a donde vamos a emitir la peticion
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id);

}
