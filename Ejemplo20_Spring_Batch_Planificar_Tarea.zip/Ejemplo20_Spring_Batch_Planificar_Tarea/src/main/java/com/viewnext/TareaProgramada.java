package com.viewnext;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class TareaProgramada {
	
	@Scheduled(fixedRate = 2000)   // milisegundos
	public void mostrarMensaje() {
		System.out.println("Esto es una tarea programada");
	}

}
