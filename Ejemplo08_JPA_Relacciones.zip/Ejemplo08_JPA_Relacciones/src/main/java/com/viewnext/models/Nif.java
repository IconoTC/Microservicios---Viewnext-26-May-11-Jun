package com.viewnext.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Ejemplo8_Nifs")
public class Nif implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Autoincremental
	@Column(name = "id_nif", nullable = false)
	private Long id;

	private char letra;
	private long numero;

	@OneToOne(mappedBy = "nif")   // propiedad en la entidad Persona
	private Persona p;

	public Nif() {
		// TODO Auto-generated constructor stub
	}

	public Nif(char letra, long numero) {
		super();
		this.letra = letra;
		this.numero = numero;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public char getLetra() {
		return letra;
	}

	public void setLetra(char letra) {
		this.letra = letra;
	}

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public Persona getP() {
		return p;
	}

	public void setP(Persona p) {
		this.p = p;
	}

	@Override
	public String toString() {
		return "Nif [id=" + id + ", letra=" + letra + ", numero=" + numero + "]";
	}

}
