package com.viewnext.models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Ejemplo8_Coches")
public class Coche implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Autoincremental
	@Column(name = "id_coche", nullable = false)
	private Long id;

	private String matricula;
	private String modelo;

	@ManyToMany(mappedBy = "coches", 
			cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
	private Set<Persona> propietarios = new HashSet<>();

	public Coche() {
		// TODO Auto-generated constructor stub
	}

	public Coche(String matricula, String modelo) {
		super();
		this.matricula = matricula;
		this.modelo = modelo;
	}
	
	// Metodo de sincronizacion
	public void addPropietario(Persona p) {
		propietarios.add(p);
		p.getCoches().add(this);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public Set<Persona> getPropietarios() {
		return propietarios;
	}

	public void setPropietarios(Set<Persona> propietarios) {
		this.propietarios = propietarios;
	}

	@Override
	public String toString() {
		return "Coche [id=" + id + ", matricula=" + matricula + ", modelo=" + modelo + "]";
	}

}
