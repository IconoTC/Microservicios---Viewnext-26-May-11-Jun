package com.viewnext.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewnext.models.Carrito;
import com.viewnext.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;

	@Override
	public Carrito crear(String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Carrito consultar(String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

}
