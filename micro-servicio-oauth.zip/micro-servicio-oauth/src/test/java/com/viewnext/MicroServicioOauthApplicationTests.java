package com.viewnext;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicioOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
