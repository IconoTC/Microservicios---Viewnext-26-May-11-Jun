package com.viewnext.business;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.viewnext.clients.UsuarioClienteREST;
import com.viewnext.models.Usuario;

@Service
public class UsuarioServiceImpl implements IUsuarioService, UserDetailsService{
	
	@Autowired
	private UsuarioClienteREST clienteFeign;

	@Override
	public Usuario findByUsername(String username) {
		return clienteFeign.findByUsername(username);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Usuario usuario = findByUsername(username);
		
		if (usuario == null) {
			System.out.println("Error en las credenciales, no existe el usuario " + username);
			throw new UsernameNotFoundException("El usuario " + username + " no existe" );
		}
		
		List<GrantedAuthority> permisos = usuario.getRoles()
				.stream()
				.map(role -> new SimpleGrantedAuthority(role.getNombre()))
				.peek(permiso -> System.out.println(permiso.getAuthority()))
				.collect(Collectors.toList());
		
		System.out.println("Usuario autenticado: " + username);
		
		return new User(usuario.getUsername(), usuario.getPassword(), usuario.isEnabled(), true, true, true, permisos);
	}

}
