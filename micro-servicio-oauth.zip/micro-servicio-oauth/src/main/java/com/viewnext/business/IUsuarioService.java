package com.viewnext.business;

import com.viewnext.models.Usuario;

public interface IUsuarioService {
	
	public Usuario findByUsername(String username);

}
