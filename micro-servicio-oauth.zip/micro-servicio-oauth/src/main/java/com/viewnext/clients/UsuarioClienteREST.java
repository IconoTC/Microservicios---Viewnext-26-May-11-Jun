package com.viewnext.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.viewnext.models.Usuario;

@FeignClient(name = "servicio-usuarios")
public interface UsuarioClienteREST {
	
	// Mapear a donde vamos a emitir la peticion
	@GetMapping(path = "/usuarios/search/buscar-username")
	public Usuario findByUsername(@RequestParam  String username);

}
